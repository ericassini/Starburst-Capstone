# Deployment Notes

## Overview

This deployment is intended for local development. It includes the following
resources/components:

- SEP cluster with coordinator and two worker pods
- LDAP authentication
- Insights and local Insights database (Postgres)
- Local OpenLDAP server secured with TLS
- BIAC is configured

## Deployment Instructions

Read the notes below to make use of this environment. Be sure to follow the
steps in order.

Preliminary commands:

```bash
# Spin up local K8s cluster 
# Step 1- Create kind cluster; run command below, remove quotes around local 
kind create cluster --name 'local'

# Step 2- Create secret docker-registry
# Remove all brackets and dollar signs
# username and password located in 'harbor credentials/license & Credentials' in Starburst Orbit
# email is your kubrick email
kubectl create secret docker-registry registry-credentials --docker-server=harbor.starburstdata.net --docker-username=${USER} --docker-password=${PASSWORD} --docker-email=${EMAIL}

# Step 3- run below command (line 33)
kubectl apply -f k8s/manifests/
# Step 4- run line 35 - Replace the from-file value with the path that your starburst license is in. You should have downloaded your license during the training modules. 
kubectl create secret generic starburst-license --from-file="${HOME}"/Work/license/starburstdata.license

# Step 4- Provisions local Insights DB and links Docker/K8s networks, run line 38
docker compose -f capstone-services/docker-compose.yaml up -d

# Step 5- connect catpstone services to local control plane, run line 41
docker network connect capstone-services_default local-control-plane

# Step 6- Install SEP chart, run line 44 - make sure you are in the directory containing you k8s folder 
helm upgrade sep starburstdata/starburst-enterprise --install --version 413.1.0 --values k8s/helm/values.yaml

# Step 7- Forward coordinator port( cannot be done until after questions 1-3 are complete, wait on this)
kubectl port-forward pod/<coordinator> 8443:8443

# NOTE: must type 'thisisunsafe' in browser due to self-signed cert
```